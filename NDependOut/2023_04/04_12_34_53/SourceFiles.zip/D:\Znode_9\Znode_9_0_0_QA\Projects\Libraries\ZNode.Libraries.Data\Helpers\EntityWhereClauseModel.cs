﻿namespace Znode.Libraries.Data.Helpers
{
    public class EntityWhereClauseModel
    {
        public string WhereClause { get; set; }
        public object[] FilterValues { get; set; }
    }
}
